# React Posts App

This project is a simple CRUD application built using React.js, Axios, and Tailwind CSS.