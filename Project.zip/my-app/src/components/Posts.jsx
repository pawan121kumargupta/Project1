import { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Posts = () => {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPosts = async () => {
      const res = await axios.get('/api/posts');
      setPosts(res.data);
    };
    fetchPosts();
  }, []);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-2xl">
      <h2 className="text-xl font-semibold mb-4">All Posts</h2>
      <button onClick={() => navigate('/create')} className="bg-blue-500 text-white p-2 rounded mb-4">Create New Post</button>
      {posts.map((post) => (
        <div key={post.id} className="border-b p-2">
          <h3 className="text-lg font-bold">{post.title}</h3>
          <p>{post.content}</p>
        </div>
      ))}
    </div>
  );
};

export default Posts;
